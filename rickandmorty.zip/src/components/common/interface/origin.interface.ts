export interface Origin {
    id: number;
    name: string;
    type: string;
    dimension: string;
    created: string;
}