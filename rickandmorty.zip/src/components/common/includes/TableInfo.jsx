const TableInfo = (props) => {
    return <div>
        Showing 20 of {props.totalPages}
    </div>
}

export default TableInfo